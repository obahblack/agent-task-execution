# ticket-001 — Evaluation

- E1 (R1): Provide reproduction attempt inputs, actual output, environment, and diagnosis supported by logs, or document inability to reproduce and next evidence needed.
