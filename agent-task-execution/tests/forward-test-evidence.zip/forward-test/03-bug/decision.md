Cause unknown does not block bounded investigation. Fix is a separate authorized outcome only if requested; no invented diagnosis.
