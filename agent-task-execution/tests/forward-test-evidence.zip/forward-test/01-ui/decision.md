Single ticket. Existing implementation request authorizes execution; no second approval.
