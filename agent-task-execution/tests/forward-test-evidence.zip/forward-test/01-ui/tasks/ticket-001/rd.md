# ticket-001 — Relabel pricing CTA

## Objective
Relabel pricing CTA

## Requirements
- R1: Change Submit to Start free trial on pricing CTA.

## Dependencies
[]
