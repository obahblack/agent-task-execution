# ticket-001 — Evaluation

- E1 (R1): Parse pricing.html and observe exact CTA text Start free trial.
