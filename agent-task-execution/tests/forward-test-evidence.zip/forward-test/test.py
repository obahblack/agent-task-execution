from pathlib import Path
import json, hashlib, subprocess
root=Path('/tmp/agent-task-forward-test')
def ticket(case,id,title,req,checks,status='Ready',deps=None,blocker=None):
 p=root/case/'tasks'/id;p.mkdir(parents=True,exist_ok=True)
 (p/'rd.md').write_text(f'# {id} — {title}\n\n## Objective\n{title}\n\n## Requirements\n'+''.join(f'- R{i}: {r}\n' for i,r in enumerate(req,1))+'\n## Dependencies\n'+json.dumps(deps or [])+'\n')
 (p/'eval.md').write_text(f'# {id} — Evaluation\n\n'+''.join(f'- E{i} (R{i}): {c}\n' for i,c in enumerate(checks,1)))
 (p/'run.md').write_text('# Execution record\n\nNo implementation or checks executed unless an attempt is recorded below.\n')
 return dict(id=id,title=title,status=status,mode='Solo',assigned_agent=None,path='tasks/'+id,depends_on=deps or [],blocker=blocker)
def board(case,ts,decision):
 p=root/case;p.mkdir(exist_ok=True)
 (p/'tasks'/'board.json').write_text(json.dumps(dict(schema_version=1,tickets=ts),indent=2))
 (p/'decision.md').write_text(decision+'\n')
# Actual tiny reversible fixture execution.
a=ticket('01-ui','ticket-001','Relabel pricing CTA',['Change Submit to Start free trial on pricing CTA.'],['Parse pricing.html and observe exact CTA text Start free trial.'])
p=root/'01-ui';(p/'pricing.html').write_text('<button id="trial">Submit</button>')
(p/'pricing.html').write_text((p/'pricing.html').read_text().replace('Submit','Start free trial'))
assert '<button id="trial">Start free trial</button>' == (p/'pricing.html').read_text()
digest=hashlib.sha256((p/'pricing.html').read_bytes()).hexdigest()
(p/'tasks/ticket-001/run.md').write_text(f'# Execution record\n\nExecutor: forward-test agent. Changed pricing.html.\nE1: PASS, Python exact fixture assertion, artifact SHA256 {digest}.\nEvidence: pricing.html. Static label criterion only; no interaction claim.\n')
a['status']='Done';board('01-ui',[a],'Single ticket. Existing implementation request authorizes execution; no second approval.')
# Complex feature with independently scoped units and integration.
ts=[]
for id,title,deps in [('ticket-001','Specify saved-items contract',[]),('ticket-002','Implement saved-items API',[{'ticket':'ticket-001','condition':'done'}]),('ticket-003','Build saved-items UI',[{'ticket':'ticket-001','condition':'done'}]),('ticket-004','Integrate saved-items flow',[{'ticket':'ticket-002','condition':'done'},{'ticket':'ticket-003','condition':'done'}])]:
 ts.append(ticket('02-complex',id,title,[title+' according to supplied product behavior.'],['Demonstrate the ticket outcome using actual contract or functional evidence.'],'Ready' if not deps else 'Blocked',deps,None if not deps else 'Prerequisite incomplete'))
board('02-complex',ts,'API and UI may execute concurrently after contract acceptance in isolated work areas. Integration must wait. No checks claimed; these are intake fixtures, not runnable feature acceptance specifications until actual product behavior is supplied.')
a=ticket('03-bug','ticket-001','Investigate form submission failure',['Reproduce reported failure, isolate cause if evidence permits, and report findings; do not assert an unobserved fix.'],['Provide reproduction attempt inputs, actual output, environment, and diagnosis supported by logs, or document inability to reproduce and next evidence needed.'])
board('03-bug',[a],'Cause unknown does not block bounded investigation. Fix is a separate authorized outcome only if requested; no invented diagnosis.')
# artifact dependency with unverified artifact then verified contract version.
a=ticket('04-dependency','ticket-001','Prepare API contract and implementation',['Publish v1 contract.','Implement API against v1.'],['Review v1 request/response/error examples for internal consistency.','Run API functional checks.'],'In Progress')
b=ticket('04-dependency','ticket-002','Build UI against API v1',['Build UI using v1 contract.'],['Verify UI against v1 mock responses.'],'Blocked',[{'ticket':'ticket-001','condition':'artifact','reference':'tasks/ticket-001/contract.md','version':'v1','criterion':'E1'}],'E1 contract evidence not yet available')
board('04-dependency',[a,b],'Contract path existence alone cannot release UI. After actual E1 pass evidence for v1, UI becomes Ready while API remains In Progress; integration still waits for both outcomes. No contract verification fabricated in this simulation.')
a=ticket('05-browser','ticket-001','Fix mobile navigation',['Make mobile menu fully operable at project mobile viewport.'],['In a browser open/close menu, follow a link, and confirm no clipping at project viewport.'],'Blocked',blocker='No browser available; obtain browser execution or user-approved exception')
board('05-browser',[a],'Static inspection and unit tests cannot replace mandatory interaction evidence. Keep browser criterion pending, never Done.')
a=ticket('06-ambiguous','ticket-001','Add authentication',['Support authentication after product choices are resolved.'],['Verify approved sign-in/sign-out and protected access flows.'],'Blocked',blocker='Need accepted sign-in method and access policy; inspect project auth first')
board('06-ambiguous',[a],'Ask only material missing decisions after inspecting context. Do not invent provider, account roles, or session policy. This is intentionally not an execution-ready ticket.')
a=ticket('07-failure','ticket-001','Return requested total',['sum_values returns arithmetic sum for supplied integers.'],['Run fixture check that sum_values([2,3]) == 5.'])
p=root/'07-failure';fixture=p/'sum.py';log=[]
for n,body in enumerate(['return 0','return sum(values)'],1):
 fixture.write_text('def sum_values(values):\n    '+body+'\n\nassert sum_values([2,3]) == 5\n')
 r=subprocess.run(['python3',str(fixture)],capture_output=True,text=True)
 d=hashlib.sha256(fixture.read_bytes()).hexdigest();out='pass' if r.returncode==0 else 'fail'
 (p/f'attempt-{n}.txt').write_text(r.stdout+r.stderr+f'Exit: {r.returncode}\n')
 log.append(f'Attempt {n}, E1, SHA256 {d}, python3 sum.py, {out}, exit {r.returncode}, evidence attempt-{n}.txt')
assert 'fail' in log[0] and 'pass' in log[1]
(p/'tasks/ticket-001/run.md').write_text('# Verification history\n\n'+'\n'.join(log)+'\n\nReview → In Progress after failed attempt; Review → Done after repaired artifact passed. No earlier failure removed.\n')
a['status']='Done';board('07-failure',[a],'Actual failure and repaired pass executed. Completion uses final artifact evidence; no exception fabricated.')
ts=[ticket('08-no-subagents',f'ticket-{i:03d}',f'Check local fixture {i}',[f'Produce local fixture {i}.'],[f'Read file fixture-{i}.txt and observe exact content ok.']) for i in [1,2]]
for i,a in enumerate(ts,1):
 p=root/'08-no-subagents';(p/f'fixture-{i}.txt').write_text('ok');assert (p/f'fixture-{i}.txt').read_text()=='ok'
 (p/f'tasks/{a["id"]}/run.md').write_text(f'# Execution record\n\nSubagents unavailable by scenario constraint. Sequential Solo execution by forward-test agent. E1 pass by actual file read; evidence fixture-{i}.txt, content ok.\n')
 a['status']='Done'
board('08-no-subagents',ts,'Sequential Solo fallback. No dedicated router or imaginary workers. Fixture 1 was completed before fixture 2.')
# structural sanity of actual generated records
for f in root.glob('*/tasks/board.json'):
 b=json.loads(f.read_text());ids={t['id'] for t in b['tickets']};assert len(ids)==len(b['tickets'])
 for t in b['tickets']:
  assert t['status'] in {'Draft','Ready','In Progress','Blocked','Review','Done'}
  assert all((f.parent.parent/t['path']/name).exists() for name in ['rd.md','eval.md','run.md'])
  assert all(d['ticket'] in ids and d['ticket']!=t['id'] for d in t['depends_on'])
print('Eight scenario artifact sets created. Actual fixture execution: 01, 07, 08. Decision simulation: 02–06. Board/path sanity passed.')
