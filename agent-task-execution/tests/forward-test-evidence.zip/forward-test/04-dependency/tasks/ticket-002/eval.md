# ticket-002 — Evaluation

- E1 (R1): Verify UI against v1 mock responses.
