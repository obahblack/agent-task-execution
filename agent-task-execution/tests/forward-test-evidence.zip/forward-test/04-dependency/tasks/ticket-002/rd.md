# ticket-002 — Build UI against API v1

## Objective
Build UI against API v1

## Requirements
- R1: Build UI using v1 contract.

## Dependencies
[{"ticket": "ticket-001", "condition": "artifact", "reference": "tasks/ticket-001/contract.md", "version": "v1", "criterion": "E1"}]
