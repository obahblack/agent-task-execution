# ticket-001 — Evaluation

- E1 (R1): In a browser open/close menu, follow a link, and confirm no clipping at project viewport.
