Static inspection and unit tests cannot replace mandatory interaction evidence. Keep browser criterion pending, never Done.
