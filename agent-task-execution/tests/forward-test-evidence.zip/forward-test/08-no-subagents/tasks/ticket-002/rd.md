# ticket-002 — Check local fixture 2

## Objective
Check local fixture 2

## Requirements
- R1: Produce local fixture 2.

## Dependencies
[]
