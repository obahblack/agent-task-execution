# ticket-002 — Evaluation

- E1 (R1): Read file fixture-2.txt and observe exact content ok.
