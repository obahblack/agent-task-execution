# ticket-001 — Check local fixture 1

## Objective
Check local fixture 1

## Requirements
- R1: Produce local fixture 1.

## Dependencies
[]
