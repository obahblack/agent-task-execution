# ticket-001 — Evaluation

- E1 (R1): Read file fixture-1.txt and observe exact content ok.
