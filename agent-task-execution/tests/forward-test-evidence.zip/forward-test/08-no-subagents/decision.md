Sequential Solo fallback. No dedicated router or imaginary workers. Fixture 1 was completed before fixture 2.
