Ask only material missing decisions after inspecting context. Do not invent provider, account roles, or session policy. This is intentionally not an execution-ready ticket.
