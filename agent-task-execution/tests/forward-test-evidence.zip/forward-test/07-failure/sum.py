def sum_values(values):
    return sum(values)

assert sum_values([2,3]) == 5
