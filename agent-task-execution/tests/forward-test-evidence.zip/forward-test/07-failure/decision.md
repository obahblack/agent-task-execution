Actual failure and repaired pass executed. Completion uses final artifact evidence; no exception fabricated.
