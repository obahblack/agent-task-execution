# ticket-001 — Return requested total

## Objective
Return requested total

## Requirements
- R1: sum_values returns arithmetic sum for supplied integers.

## Dependencies
[]
