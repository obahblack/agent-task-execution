# Verification history

Attempt 1, E1, SHA256 c8e0616ca6ec4708774e9d2baabe8b103bec8d515b9c22ff9ecd3bc1b0e92b28, python3 sum.py, fail, exit 1, evidence attempt-1.txt
Attempt 2, E1, SHA256 391184619f6c46129857e4f3641cd3943651c89b983b44243d61a8a6b4155456, python3 sum.py, pass, exit 0, evidence attempt-2.txt

Review → In Progress after failed attempt; Review → Done after repaired artifact passed. No earlier failure removed.
