# ticket-001 — Evaluation

- E1 (R1): Run fixture check that sum_values([2,3]) == 5.
